﻿using System.ComponentModel.DataAnnotations;
using System.Numerics;

namespace MVCRouting.Models
{
    public class Student
    {
        [Key]
        public int StudentId { get; set; }

        [Required(ErrorMessage = "Please enter the first name.")]
        public string FirstName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter the last name.")]
        public string LastName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter a grade.")]
        public double Grade { get; set; }

    }
}

