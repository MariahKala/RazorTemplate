﻿using Microsoft.EntityFrameworkCore;
using MVCRouting.Models;
using System.Numerics;

namespace MVCRouting.Models
{
    public class StudentContext : DbContext
    {
        public StudentContext(DbContextOptions<StudentContext> options)
           : base(options)
        { }
        public DbSet<Student> Students { get; set; } = null!;
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Student>().HasData(
                new Student
                {
                    StudentId = 1,
                    FirstName = "Mariah",
                    LastName = "Kennedy",
                    Grade = 74.50,
           
                },

                new Student
                {
                    StudentId = 2,
                    FirstName = "Esther",
                    LastName = "Frank",
                    Grade = 33.50,

                },
                new Student
                {
                    StudentId = 3,
                    FirstName = "John",
                    LastName = "Doe",
                    Grade = 93.50,


                }

        );


        }
    }
}

