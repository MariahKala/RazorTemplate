﻿using MVCRouting.Models;

namespace MVCRouting.Models
{
    public class StudentViewModel
    {
        public List<Student>? Students { get; set; }
        public int AccessLevel { get; set; }
    }
}
