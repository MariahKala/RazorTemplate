﻿using Microsoft.AspNetCore.Mvc;
using MVCRouting.Models;

namespace MVCRouting.Controllers
{
        public class StudentController : Controller
        {
            private readonly StudentContext _context;

            public StudentController(StudentContext context)
            {
                _context = context;
            }

            public IActionResult DisplayStudents(int accessLevel)
            {
                // Retrieve students from the database
                var students = _context.Students.ToList();

                // Create a view model with the retrieved students and access level
                var viewModel = new StudentViewModel
                {
                    Students = students,
                    AccessLevel = accessLevel
                };

                // Return the view with the view model
                return View(viewModel);
            }
        }

    }

